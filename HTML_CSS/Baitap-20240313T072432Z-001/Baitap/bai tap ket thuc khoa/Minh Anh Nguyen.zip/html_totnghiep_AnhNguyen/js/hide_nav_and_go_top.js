
function showmenu() {
	if ($(".nav").css('display') == 'none') {
		$(".nav").fadeIn("fast");
	}
	else {
		$(".nav").fadeOut("fast");
	}
}

window.onscroll = function () { scroll_function() };

function scroll_function() {
	if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
		document.getElementById("go-top-button").style.display = "block";
	} else {
		document.getElementById("go-top-button").style.display = "none";
	}
}

// When the user clicks on the button, scroll to the top of the document
function go_top_function() {
	document.body.scrollTop = 0; // For Safari
	document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}