	
function showmenu()
	{
		if($(".nav").css('display')=='none')
		{
			$(".nav").fadeIn("fast");
		}
		else
		{
			$(".nav").fadeOut("fast");
		}
	}