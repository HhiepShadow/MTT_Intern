function isEqual(obj1, obj2) {
    // your code
}

isEqual({ a: 1 }, { a: 1 }) // true
isEqual({ a: 1, b: 2 }, { a: 1, b: 3 }) // false
isEqual([{ a: 1 }, { b: 2 }], [{ a: 1 }, { b: 2 }]) // true